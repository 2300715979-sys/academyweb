<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gid Academy</title>
    <link rel="stylesheet" href="course.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- <nav>
        <a href="INDEX.HTML">HOME</a>
        <a href="about us.html">ABOUT US</a>
        <a href="contact us.html">CONTACT US</a>
       </nav>  -->
       <header>
        <div class="jjj">
            <img src=".png" alt="MY Logo"> <!-- Replace with actual logo -->
        </div>
        <nav>
            
                <a href="INDEX.HTML">Home</a>
              <a href="about us.html">About Us</a>
              <a href="contact us.html">Contact us</a>
             
            
        </nav>
      
        <!-- Social Media Icons & Search -->
        <div class="icons">
            <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="social"><i class="fab fa-twitter"></i></a>
            <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
            <a href="#" class="search-icon"><i class="fas fa-search"></i></a>
        </div>
      </header>
       <section class="services">
        <h2>MORE COURSES</h2>
        <div class="services-container">

            <div class="servicess">
                <h3>PROGRAMING FUNDAMENTALS</h3>
                <p>This course takes aperiod of 3months</p>
            </div>

            <div class="servicess">
                <h3>DIGITAL MARKETING</h3>
                <p>We offer a course of digital marketing which runs for 4 months</p>
            </div>

            <div class="servicess">
                <h3>DATA ANALYSIS</h3>
                <p>We also train data Analylists for 5 months</p>
            </div>

            <div class="servicess">
                <h3>CYBER SECURITY ESSENTIALS</h3>
                <p>We train cyber security essential at our hub for 3months.</p>
            </div>

            <div class="servicess">
                <h3>24/7 Customer Support</h3>
                <p>Our customer support team is always ready to assist you with your queries.</p>
            </div>

        </div>
    </section>
    <footer>
        <p>&copy; 2024. Copyright Reserved | MR.BLAIR</p>
      </footer>
</body>
</html>