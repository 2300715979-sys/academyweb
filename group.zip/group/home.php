<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gid Academy</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body> 
  <nav>
   <div class="top-bar">
  <ul>
      <li><a href="#">HH</a></li>
      <li><a href="#">Reports & Resources</a></li>
      <li><a href="#">Supply & Tenders</a></li>
      <li><a href="#">FAQs</a></li>
  </ul>
</div> 

<!-- Main Navbar -->
<header>
  <div class="jjj">
      <!-- <img src=".png" alt="MY Logo"> Replace with actual logo -->
       <h3>Gid Academy</h3>
  </div>
  <nav>
        <a href="index.php">Logout</a>
        <a href="signup.php">Register</a>
          <a href="home.php">Home</a>
        <a href="about us.php">About Us</a>
        <a href="contact us.php">Contact us</a>
       
      
  </nav>

  <!-- Social Media Icons & Search -->
  <div class="icons">
      <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
      <a href="#" class="social"><i class="fab fa-twitter"></i></a>
      <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
      <a href="#" class="search-icon"><i class="fas fa-search"></i></a>
  </div>
</header>

   <!-- <nav>
    <a href="INDEX.HTML">HOME</a>
    <a href="about us.html">ABOUT US</a>
    <a href="contact us.html">CONTACT US</a>
   </nav>  -->
   <div class="slider">
    <div class="slides">
      <img src="image/5.jpg" alt="Slide 1">
      <img src="image/2.jpg" alt="Slide 2">
      <img src="image/3.jpg" alt="Slide 3">
      <img src="1.jpg" alt="Slide 3">
      <img src="image/4.jpg" alt="Slide 3">
  </div>
   </div>
   <!-- <marquee behavior="right" direction="scroll">WELCOME TO OUR HUB</marquee> -->
   <!-- <div class="welcome">
    <h1>WELCOME TO OUR HUB</h1>
    <p>At our platform we offer avariety of courses but mainly online</p>
  <div class="courses">
    <div class="ourcourses">
        <img src="images (1).jpeg" alt="">
        <h2>TELECOMUNICATION ENGNEERING</h2>
        <P>Telecommunication is agaood course studied on our hub.<br>it requres one to have passed ict in a level plus atleast acredit in science subjects at Olevel.</P>
    </div>
    <div class="ourcourses">
        <img src="images (3).jpeg" alt="">
        <h2>INFORMATION TECHNOLOGY BUSINESS</h2>
        <P>Information Technology Business is one of the common courses offerd online at our hub.<br>.it is athree year course which requres one to have passed ict and atleast apass in every subject at ordinally level</P>
    </div>
    <div class="ourcourses">
        <img src="images (2).jpeg" alt="">
        <h2>DIPLOMA IN COMPUTER TECHNOLOGY</h2>
        <P>Diploma in Computer Technology is a two year course that we offer to our clients.,<br>One must have atlest Uganda Certificate Of Education or its equvalent in order to qualify for the offer.Successful students are rewarded adiploma at the end of two years.</P>
    </div>
  </div>
  <div> -->
    <section class="why-choose-us">
      <div class="container">
          <div class="image">
              <img src="image/5.jpg" alt=""> <!-- Replace with the actual image source -->
          </div>
          <div class="content">
              <h2>Who are we...</h2>
              <h2>Why Choose <span class="highlight">Group Academy</span></h2>
              <p>
                  By choosing Group Academy, students can expect a unique,high-quality education that reflects our academy's
                  passion ,while also supporting our local community and receiving exceptional customer service.
              </p>
              <ul>
                  <li>QUALITY AND UNIQUENESS</li>
                  <h5>Originality:</h5> <p> offers one-of-a- kind,quality education that can't be found elsewhere.</p>
                  <li>PERSONAL CONNECTION</li>
                  <h5>supporting our students:</h5> <p>By choosing Group Academy,students with special needs are given half support of the total tution ad by doing this we support them</p>
                  <h5>Affordable Education:</h5> <p>Our tution structures/bills are affordable to most parents which makes us unique</p>
                 
              </ul>
              <a href="courses.php" class="btn-green">Find Out More</a>
          </div>
      </div>
      <div>
      </section>

      <!-- <div class="servicesss">
        <div class="service-card">
            <h3>Software Engneering</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum, nisi....</p>
        </div>
    
        <div class="service-card">
            <h3>Java programming</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum, nisi...</p>
        </div>
    
        <div class="service-card">
            <h3>Computer studies</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum, nisi....</p>
        </div>
    
        <div class="service-card">
            <h3>Web application Development</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorum, nisi..</p>
        </div>
    
      
      </div> -->
      <section class="servic">
        <div class="service-card">
            <h3>Business and Entrepreneurship
            </h3>
            <p>Students learn the fundamentals of starting and managing a business, including marketing, financial planning, and leadership. Real-world case studies and business plan development are included.

            </p>
        </div>
    
        <div class="service-card">
            <h3>
                Biomedical Science
                </h3>
            <p>Covers human anatomy, genetics, medical technology, and disease prevention. This course is ideal for students interested in healthcare careers.
            </p>
        </div>
    
        <div class="service-card">
            <h3>Digital Media and Design
            </h3>
            <p>Focuses on graphic design, video editing, and digital storytelling. Students learn to use tools like Photoshop, Premiere Pro, and Illustrator.
            </p>
        </div>
    
        <div class="service-card">
            <h3>Law and Ethics
            </h3>
            <p>Provides an introduction to legal systems, human rights, and ethical decision-making. Case studies and debates help students understand real-world legal applications.
            </p>
        </div>
        <div class="service-card">
            <h3>Computer Science</h3>
            <p>This course introduces students to programming, algorithms, and problem-solving using languages like Python and Java. It also covers web development, cybersecurity, and data structures.</p>
        </div>
        <div class="service-card">
            <h3>Engineering and Robotics
            </h3>
            <p>Covers mechanical and electrical engineering principles. Students build and program robots, learning about automation and AI applications.
            </p>
        </div>
        <div class="service-card">
            <h3>Environmental Science
            </h3>
            <p>Focuses on climate change, conservation, and sustainable solutions. Hands-on projects include field research and environmental impact assessments.
            </p>
        </div>
        <div class="service-card">
            <h3>Psychology</h3>
            <p>This course explores human behavior, cognitive processes, and emotional development. Topics include psychological theories, mental health, and social behavior.
            </p>
        </div>
        <div class="service-card">
            <h3>Music and Performing Arts
            </h3>
            <p>Teaches music theory, composition, and performance. Students explore acting, stage production, and musical instruments.
            </p>
        </div>
      
    </section>
    

      <button class="scroll-up-btn">↑</button>  
  <div class="buttons">
     <!-- <p><a href="courses.html">more courses</a></p>  -->
  </div>
 
  <!-- <a href="https://wa.me/+256 763860855" class="whatsapp-float" target="_blank"> 
      <img src="hhhhhh.png" alt="WhatsApp"></a>  -->
      <div class="wat">
      <a href="https://wa.me/+256763860855" class="whatsapp-float" target="_blank"> 
        <img src="image/hhhhhh.png" alt="WhatsApp"> 
   </a>
</div>
  <!-- <footer>
    <p>&copy; 2024. Copyright Reserved | MR.BLAIR</p>
  </footer> -->
  <footer class="footer">
    <div class="footer-container">
        <div class="footer-section">
            <!-- <h3>Company</h3>  -->
            <ul>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">FAQs & Help</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h3>Contact</h3>
            <p>nakawa, Kampala, Uganda</p>
            <p>+256 763860855</p>
            <p>blairambasitse@gmail.com</p>
            <div class="social-icons">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div class="footer-section">
          <h3>Gallery</h3>
          <div class="gallery">
              <img src="1.jpg" alt="Gallery Image">
              <img src="image/2.jpg" alt="Gallery Image">
              <img src="image/3.jpg" alt="Gallery Image">
              <img src="image/4.jpg" alt="Gallery Image">
              <img src="image/5.jpg" alt="">
              <img src="image/21.jpg" alt="">
          </div>
      </div>

      <div class="footer-section">
          <h3>Get in touch</h3>
          <p>Reach out at our head offices in Nakawa Kampala Uganda <br>P.O.Box 123 kampala</p>
          <a href="#"></a><button class="profile-btn">View Profile</button>
      </div>
  </div>

  <div class="footer-bottom">
      <p>&copy;2025 Tonny blair, All Rights Reserved.</p>
  </div>
</footer>

  <script src="main.js"></script>
</body>
</html>