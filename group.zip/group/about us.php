<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gid Academy</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- <nav>
        <a href="INDEX.HTML">HOME</a>
        <a href="about us.html">ABOUT US</a>
        <a href="contact us.html">CONTACT US</a>
       </nav>  -->
       <header>
        <div class="jjj">
            <h3>Gid Academy</h3>
        </div>
        <nav>
            <a href="index.php">Logout</a>
            <a href="signup.php">Register</a>
                <a href="home.php">Home</a>
              <a href="about us.php">About Us</a>
              <a href="contact us.php">Contact us</a>
             
            
        </nav>
      
        <!-- Social Media Icons & Search -->
        <div class="icons">
            <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="social"><i class="fab fa-twitter"></i></a>
            <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
            <a href="#" class="search-icon"><i class="fas fa-search"></i></a>
        </div>
      </header>
      
    <!-- <div class="container">
        <div class="profile-section">
            <div class="left-column">
                <div class="profile-picture">
                    <img src="BLAIR1.jpg" alt="">
                </div>
                <h2>TONNY BLAIR</h2>
                <p>Director</p>
                <div class="contact-info">
                    <a href="mailto:blairambasitse@gmail.com"><i class="fas fa-envelope"></i>blairambasitse@gmail.com</a><br>
                    <a href="tel:+256 763860855"><i class="fas fa-phone"></i>+256 763860855</a><br>
                    <a href="https://wa.me/256 763860855"><i class="fas fa-whatsapp"></i>Chat on WhatsApp</a><br>
                    <a href="#"><i class="fas fa-file-download"></i>Download Resume</a><br>
                </div>
            </div>
            <div class="right-column">
                <h2>OUR SUMMARY</h2>
                <p class="summary">
                   Our hub was developed way back in 2023 by a software developer named Tonny Blair with the aim of improving the quality of education in the nation.
                </p>
                <p class="summary">
                    The idea was later adopted by government and the developer ended selling the project to the government which is currently managing and running it.
                </p>

                <div class="services">
                    <div class="service-box">
                        <h3>OUR MISSION</h3>
                        <p>Empowering learners of all ages to achieve their full potential through acceddible,innovative,and high-quality educational resources and experiences.</p>
                    </div>
                    <div class="service-box">
                        <h3>VISION STATEMENT</h3>
                        <p>To become a leading learning hub fostering a community of curious,creative, and critical thinkers,equipped to thrive in an ever-changing world.</p>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <div class="wat">
      <a href="https://wa.me/+256 700785764" class="whatsapp-float" target="_blank"> 
        <img src="image/hhhhhh.png" alt="WhatsApp"> 
   </a>
    <section class="hero">
        <h1>Know who we are!</h1>
        <p>Welcome to our website! We're thrilled to have you here...</p>
    </section>
    <section class="about">
        <div class="image">
            <img src="image/5.jpg" alt="Elephant in nature">
        </div>
        <div class="content">
            <h3>ABOUT US</h3>
            <h2>Know <span>About Us</span></h2>
            <p>Blair academy, located in nakawa, specializes offering quality education to all students both undergraduate and post graduate across the whole world.Aiming at giving quality education is our major priolity.we offer the following courses;</p>
            <ul>
                <li>Programming oin java</li>
                <li>computer service</li>
                <li>software development</li>
                <li>Science in accounting</li>
                <li>Database designing</li>
                <li>graphics designing</li>
            </ul>
            <button onclick="readMore()">Read More</button>
        </div>
    </section>
    <section class="team-section">
        <h3>TEAM</h3>
        <h2>Meet Our Team</h2>
        <div class="carousel-container">
            <div class="carousel">
                <div class="team-member">
                    <img src="image/mm (3).jpeg" alt="">
                    <h4>Sir Khevin</h4>
                    <p>General Manager</p>
                </div>
                <div class="team-member">
                    <img src="image/BLAIR1.jpg" alt="">
                    <h4>Tonny Blair</h4>
                    <p>Head of ICT department</p>
                </div>
                <div class="team-member">
                    <img src="image/mm (2).jpeg" alt="">
                    <h4>Elisa Kafumisi</h4>
                    <p>Minister of women affairs</p>
                </div>
                <div class="team-member">
                    <img src="image/pkesh.jpg" alt="">
                    <h4>Madam Patience</h4>
                    <p>Library Minister</p>
                </div>
                <div class="team-member">
                    <img src="image/mm (1).jpeg" alt="">
                    <h4>Guhirwa Martha</h4>
                    <p>Head of Accounting deprtment</p>
                </div>
                <div class="team-member">
                    <img src="image/gideon.jpg" alt="">
                    <h4>mr Gideon</h4>
                    <p>general Manager</p>
                </div>
                
                
            </div>
        </div>
    </section>
    <button class="scroll-up-btn">↑</button>  
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <!-- <h3>Company</h3>  -->
                <ul>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">FAQs & Help</a></li>
                </ul>
            </div>
    
            <div class="footer-section">
                <h3>Contact</h3>
                <p>nakawa, Kampala, Uganda</p>
                <p>+256 763860855</p>
                <p>blairambasitse@gmail.com</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="footer-section">
              <h3>Gallery</h3>
              <div class="gallery">
                  <img src="1.jpg" alt="Gallery Image">
                  <img src="image/2.jpg" alt="Gallery Image">
                  <img src="image/3.jpg" alt="Gallery Image">
                  <img src="image/4.jpg" alt="Gallery Image">
                  <img src="image/5.jpg" alt="">
                  <img src="image/21.jpg" alt="">
              </div>
          </div>
    
          <div class="footer-section">
              <h3>Get in touch</h3>
              <p>Reach out at our head offices in Nakawa Kampala Uganda <br>P.O.Box 123 kampala</p>
              <a href="#"></a><button class="profile-btn">View Profile</button>
          </div>
      </div>
    
      <div class="footer-bottom">
          <p>&copy;2025 Tonny blair, All Rights Reserved.</p>
      </div>
    </footer>
<script src="main.js"></script>
</body>
</html>